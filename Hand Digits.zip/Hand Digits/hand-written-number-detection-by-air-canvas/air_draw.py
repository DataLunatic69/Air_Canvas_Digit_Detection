import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf
import landmarks as lm
from landmarks import handDetector



def draw():
    mp_drawing = mp.solutions.drawing_utils
    mp_hands = mp.solutions.hands

    # Load the trained model
    model = tf.keras.models.load_model('./dense_model.h5')

    cap = cv2.VideoCapture(0)
    img = np.zeros((504, 504, 1), np.uint8)
    detector = handDetector(maxHands=1)
    
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            print("Ignoring empty camera frame.")
            continue

        # Process the frame for hand landmarks
        frame = detector.findHands(frame)
        lmList, bbox = detector.findPosition(frame)

        if len(lmList) != 0:
            x1, y1 = lmList[8][1:]  # Index finger tip
            x4, y4 = lmList[4][1:]  # Thumb tip
            if abs(x1 - x4) > 15 and abs(y1 - y4) > 15:
                cv2.circle(img, (x1, y1), color=(255, 120, 80), radius=5, thickness=15)

            # Draw hand landmarks and connections
            mp_drawing.draw_landmarks(frame, detector.results.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS)

            # Prepare for digit prediction
            a = cv2.resize(img, (28, 28))
            a = a.reshape(-1, 28, 28, 1)
            a = a / 255.0
            result = model.predict(a)
            z = np.argmax(result)

            # Display the predicted digit on the frame
            org = (200, 250)
            font = cv2.FONT_HERSHEY_SIMPLEX
            fontScale = 8
            color = (255, 0, 0)
            thickness = 3
            cv2.putText(frame, str(z), org, font, fontScale, color, thickness, cv2.LINE_AA)

        # Show the image with drawing
        cv2.imshow('MediaPipe Hands', frame)

        # Check for ESC key to exit and display prediction
        if cv2.waitKey(1) & 0xFF == 27:
            cv2.destroyAllWindows()
            break

    cap.release()
    cv2.destroyAllWindows()

    # Show the final prediction in a new window
    img_result = np.ones((504, 504, 1), np.uint8)
    cv2.putText(img_result, str(z), (200, 250), font, fontScale, color, thickness, cv2.LINE_AA)
    cv2.imshow('Predicted Digit', img_result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    draw()
