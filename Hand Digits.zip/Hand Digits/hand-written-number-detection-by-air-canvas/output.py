import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.datasets import mnist
import landmarks as lm

# Load the trained model
model = tf.keras.models.load_model('./dense_model.h5')

# Load MNIST dataset
(x_train, y_train), (_, _) = mnist.load_data()

# Initialize the hand detector
cap = cv2.VideoCapture(0)
detector = lm.handDetector(maxHands=1)

# Create a black image for drawing
draw_canvas = np.zeros((480, 640), dtype=np.uint8)
last_x, last_y = None, None
drawing = False

while True:
    _, img = cap.read()
    img = cv2.flip(img, 1)  # Flip the image horizontally for a mirror effect
    
    # Detect hand landmarks
    img = detector.findHands(img)
    lmList, bbox = detector.findPosition(img)

    if len(lmList) != 0:
        fingers = detector.fingersUp()

        x1, y1 = lmList[8][1:]  # Index finger tip coordinates
        
        if fingers[1] == 1 and all(f == 0 for f in fingers[2:]):
            drawing = True
        elif fingers[1] == 1 and fingers[2] == 1:
            drawing = False
        elif all(fingers):
            draw_canvas = np.zeros((480, 640), dtype=np.uint8)  # Clear canvas

        if drawing and last_x is not None and last_y is not None:
            cv2.line(draw_canvas, (last_x, last_y), (x1, y1), (255, 255, 255), 8)  # Set thickness to 8

        last_x, last_y = x1, y1

        # Skip the smoothing to avoid fading

        # Prepare the drawing for prediction
        drawing_resized = cv2.resize(draw_canvas, (28, 28))
        drawing_resized = drawing_resized.reshape(-1, 28, 28, 1) / 255.0

        # Predict the digit
        result = model.predict(drawing_resized)
        z = np.argmax(result)

        # Print the predicted digit to the terminal
        print(f"Predicted Digit: {z}")

        # Display the predicted digit on the camera frame
        if len(bbox) > 1:
            cv2.putText(img, str(z), (bbox[0] - 50, bbox[1] - 50), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3)
        else:
            print("Bounding box does not have enough elements.")
    
    # Combine the drawing and the camera feed
    img_with_drawing = cv2.bitwise_and(img, img, mask=draw_canvas)
    img_with_drawing = cv2.add(img, np.stack([draw_canvas] * 3, axis=-1))

    # Display the final output
    cv2.imshow("Image", img_with_drawing)

    # Press 'ESC' key to exit
    if cv2.waitKey(1) & 0xFF == 27:
        break

# Release the camera and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()

# Define the size of the output window
output_window_size = (504, 504)  # Set a larger window size

# Fetch and display the predicted digit image
digit_image = x_train[np.argmax(y_train == z)].reshape(28, 28)  # Get the image for the predicted digit
digit_image = (digit_image * 255).astype(np.uint8)  # Convert to 0-255 range for display
digit_img_colored = cv2.cvtColor(digit_image, cv2.COLOR_GRAY2BGR)  # Convert to BGR for display

# Resize the image to fit the output window
digit_img_resized = cv2.resize(digit_img_colored, output_window_size)

# Display the digit image in a larger window
cv2.imshow("Predicted Digit Image", digit_img_resized)
cv2.waitKey(0)
cv2.destroyAllWindows()
